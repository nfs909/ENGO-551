from flask import Flask, redirect, render_template, request
import requests
import json


app = Flask(__name__)

@app.route("/")
def home():
    return render_template('map.html')



@app.route("/get", methods = ['POST'])
def find():
    date1= request.form.get('date1')
    date2= request.form.get('date2')
    if date1 != '' and date2 == '':
        rp = requests.get("https://data.calgary.ca/resource/c2es-76ed.geojson?issueddate={}T00:00:00.000".format(date1))
        geojson_obj = json.dumps(rp.json(), indent=4)
        #print(geojson_obj)
        #return render_template("permit.html", geojson_obj = geojson_obj)
        return render_template("permit.html")
    if date1 != '' and date2 != '':
        rp = requests.get("https://data.calgary.ca/resource/c2es-76ed.geojson?$where=issueddate > '{}' and issueddate < '{}'".format(date1, date2))
        geojson_obj = json.dumps(rp.json(), indent=4)
        #print(geojson_obj)
        #return render_template("permit.html", geojson_obj = geojson_obj)
        return render_template("permit.html")

    
